#ifndef OBJECTIVEFUNCTION_H
#define OBJECTIVEFUNCTION_H

#include "Function.h"

class ObjectiveFunction : public Function {
public:
    ObjectiveFunction();
};

#endif
